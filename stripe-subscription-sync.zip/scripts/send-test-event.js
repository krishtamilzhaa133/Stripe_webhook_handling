'use strict';

/**
 * Sends locally-constructed, correctly-signed Stripe webhook events to your
 * running service, without needing the Stripe CLI or network access.
 *
 * Usage:
 *   node scripts/send-test-event.js happy
 *   node scripts/send-test-event.js recovery
 *
 * ("happy"    = a single invoice.payment_succeeded -> subscription becomes active)
 * ("recovery" = payment_failed -> past_due, then payment_succeeded -> active,
 *               then a REPLAYED failed event and a STALE/late failed event,
 *               both of which must NOT knock the subscription back out of
 *               "active". This is the scenario the assignment calls out
 *               explicitly: Smart Retry can redeliver payment_failed after
 *               the subscriber has already recovered.)
 */

require('dotenv').config();
const crypto = require('crypto');
const http = require('http');

const PORT = process.env.PORT || 4242;
const SECRET = process.env.STRIPE_WEBHOOK_SECRET;

if (!SECRET) {
  console.error('STRIPE_WEBHOOK_SECRET is not set. Copy .env.example to .env first.');
  process.exit(1);
}

const CUSTOMER_ID = 'cus_test_demo001';
const SUBSCRIPTION_ID = 'sub_test_demo001';

let eventCounter = 0;
function nextEventId() {
  eventCounter += 1;
  return `evt_test_${Date.now()}_${eventCounter}`;
}

function invoiceEvent(type, { created, periodEnd }) {
  return {
    id: nextEventId(),
    object: 'event',
    type,
    created,
    data: {
      object: {
        id: `in_test_${Date.now()}`,
        object: 'invoice',
        customer: CUSTOMER_ID,
        subscription: SUBSCRIPTION_ID,
        period_end: periodEnd,
        lines: {
          data: [{ period: { start: periodEnd - 30 * 24 * 3600, end: periodEnd } }],
        },
      },
    },
  };
}

function subscriptionDeletedEvent({ created, periodEnd }) {
  return {
    id: nextEventId(),
    object: 'event',
    type: 'customer.subscription.deleted',
    created,
    data: {
      object: {
        id: SUBSCRIPTION_ID,
        object: 'subscription',
        customer: CUSTOMER_ID,
        current_period_end: periodEnd,
      },
    },
  };
}

// Replicates Stripe's own signing scheme so constructEvent() on the server
// validates it exactly as it would a real webhook.
// signed_payload = "{timestamp}.{raw_json_body}"
// signature      = HMAC_SHA256(secret, signed_payload)
function sign(payload, secret, timestamp) {
  const payloadString = JSON.stringify(payload);
  const signedPayload = `${timestamp}.${payloadString}`;
  const signature = crypto.createHmac('sha256', secret).update(signedPayload, 'utf8').digest('hex');
  return {
    header: `t=${timestamp},v1=${signature}`,
    body: payloadString,
  };
}

function post(eventPayload, timestamp) {
  return new Promise((resolve, reject) => {
    const { header, body } = sign(eventPayload, SECRET, timestamp);
    const req = http.request(
      {
        hostname: 'localhost',
        port: PORT,
        path: '/webhook',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          'Stripe-Signature': header,
        },
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          console.log(`  -> HTTP ${res.statusCode}: ${data}`);
          resolve();
        });
      }
    );
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function getSubscription() {
  return new Promise((resolve, reject) => {
    http
      .get(`http://localhost:${PORT}/subscriptions/${CUSTOMER_ID}`, (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => resolve(`HTTP ${res.statusCode}: ${data}`));
      })
      .on('error', reject);
  });
}

async function runHappyPath() {
  const now = Math.floor(Date.now() / 1000);
  console.log('\n=== HAPPY PATH: invoice.payment_succeeded ===');
  console.log('1. Sending invoice.payment_succeeded (should -> active)');
  await post(invoiceEvent('invoice.payment_succeeded', { created: now, periodEnd: now + 30 * 24 * 3600 }), now);

  console.log('2. Reading back via GET /subscriptions/:customer_id');
  console.log('  ' + (await getSubscription()));
}

async function runFailureThenRecovery() {
  const t0 = Math.floor(Date.now() / 1000) - 300; // 5 min ago
  const t1 = t0 + 60; // failed
  const t2 = t1 + 120; // recovered (later, after retry succeeds)

  console.log('\n=== FAILURE -> RECOVERY, with duplicate & stale-event protection ===');

  console.log('1. invoice.payment_failed (should -> past_due)');
  const failedEvent = invoiceEvent('invoice.payment_failed', { created: t1, periodEnd: t0 + 30 * 24 * 3600 });
  await post(failedEvent, t1);
  console.log('  ' + (await getSubscription()));

  console.log('2. Stripe re-delivers the SAME payment_failed event (duplicate) — must be a no-op');
  await post(failedEvent, t1); // identical event.id -> idempotency should short-circuit this
  console.log('  ' + (await getSubscription()));

  console.log('3. Smart Retry succeeds: invoice.payment_succeeded (should -> active)');
  await post(invoiceEvent('invoice.payment_succeeded', { created: t2, periodEnd: t2 + 30 * 24 * 3600 }), t2);
  console.log('  ' + (await getSubscription()));

  console.log('4. A STALE, late-arriving payment_failed from BEFORE the recovery shows up');
  console.log('   (new event id, but its event.created is older than the succeeded event) — must NOT regress to past_due');
  const staleFailed = invoiceEvent('invoice.payment_failed', { created: t1 + 1, periodEnd: t0 + 30 * 24 * 3600 });
  await post(staleFailed, t1 + 1);
  console.log('  ' + (await getSubscription()));
  console.log('\n  Expected final status: "active" (not "past_due"). Check the JSON above.');
}

async function runCancellation() {
  const now = Math.floor(Date.now() / 1000);
  console.log('\n=== CANCELLATION: customer.subscription.deleted ===');
  await post(subscriptionDeletedEvent({ created: now, periodEnd: now }), now);
  console.log('  ' + (await getSubscription()));
}

async function main() {
  const mode = process.argv[2];
  if (mode === 'happy') {
    await runHappyPath();
  } else if (mode === 'recovery') {
    await runFailureThenRecovery();
  } else if (mode === 'cancel') {
    await runCancellation();
  } else {
    console.log('Usage: node scripts/send-test-event.js <happy|recovery|cancel>');
    process.exit(1);
  }
}

main().catch((err) => {
  console.error('Test script failed:', err);
  process.exit(1);
});
