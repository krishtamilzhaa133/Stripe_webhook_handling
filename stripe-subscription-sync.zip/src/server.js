'use strict';

require('dotenv').config();

const express = require('express');
const Stripe = require('stripe');

const { handleEvent } = require('./webhookHandler');
const subscriptionsRouter = require('./routes/subscriptions');
const db = require('./db');

const PORT = process.env.PORT || 4242;
const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;

if (!WEBHOOK_SECRET) {
  // Fail fast: a webhook service with no signing secret is a security bug,
  // not a runtime edge case.
  console.error('FATAL: STRIPE_WEBHOOK_SECRET is not set. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

// No API key needed for signature verification alone, but the Stripe SDK
// requires *some* string to construct. Verification does not call the network.
const stripe = new Stripe('sk_test_placeholder_not_used_for_verification', {
  apiVersion: '2024-06-20',
});

const app = express();
app.disable('x-powered-by');

// --- Webhook route -------------------------------------------------------
// IMPORTANT: Stripe signature verification requires the *raw, unparsed*
// request body. This route therefore uses express.raw() instead of the
// global JSON parser, and it must be registered before any body-parsing
// middleware that would consume the stream.
app.post(
  '/webhook',
  express.raw({ type: 'application/json', limit: '1mb' }),
  (req, res) => {
    const signature = req.headers['stripe-signature'];

    let event;
    try {
      event = stripe.webhooks.constructEvent(req.body, signature, WEBHOOK_SECRET);
    } catch (err) {
      console.warn(`[webhook] signature verification failed: ${err.message}`);
      return res.status(400).json({ error: 'invalid_signature' });
    }

    try {
      const result = handleEvent(event);
      console.log('[webhook]', JSON.stringify(result));
      // Always 200 once signature is valid and we've handled (or
      // deliberately ignored) the event -- this tells Stripe not to retry.
      return res.status(200).json({ received: true, ...result });
    } catch (err) {
      // An unexpected processing error: let Stripe retry via its normal
      // backoff by returning 5xx.
      console.error('[webhook] processing error:', err);
      return res.status(500).json({ error: 'processing_failed' });
    }
  }
);

// --- Everything else uses normal JSON parsing -----------------------------
app.use(express.json({ limit: '256kb' }));

app.get('/healthz', (req, res) => {
  res.status(200).json({ ok: true });
});

app.use('/subscriptions', subscriptionsRouter);

// 404 for anything unmatched
app.use((req, res) => {
  res.status(404).json({ error: 'not_found' });
});

// Centralized error handler (must have 4 args for Express to recognize it)
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[unhandled_error]', err);
  res.status(500).json({ error: 'internal_error' });
});

const server = app.listen(PORT, () => {
  console.log(`stripe-subscription-sync listening on port ${PORT}`);
});

// Graceful shutdown: close the HTTP server and the SQLite handle explicitly
// so nothing is left holding file descriptors or in-flight connections.
function shutdown(signal) {
  console.log(`\n[shutdown] received ${signal}, closing...`);
  server.close(() => {
    db.close();
    process.exit(0);
  });
  // Force-exit if close hangs (e.g. a stuck keep-alive connection)
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

module.exports = app;
