'use strict';

const { claimEvent, applySubscriptionUpdate, runInTransaction } = require('./db');

// Only these event types drive a state transition. Anything else is
// acknowledged with 200 and dropped, per the spec ("ignore gracefully").
const HANDLERS = {
  'invoice.payment_succeeded': (obj) => ({
    subscriptionId: obj.subscription,
    customerId: obj.customer,
    status: 'active',
    currentPeriodEnd: extractPeriodEnd(obj),
  }),
  'invoice.payment_failed': (obj) => ({
    subscriptionId: obj.subscription,
    customerId: obj.customer,
    status: 'past_due',
    currentPeriodEnd: extractPeriodEnd(obj),
  }),
  'customer.subscription.deleted': (obj) => ({
    subscriptionId: obj.id,
    customerId: obj.customer,
    status: 'cancelled',
    currentPeriodEnd: obj.current_period_end ?? null,
  }),
};

function extractPeriodEnd(invoice) {
  // invoice.lines.data[0].period.end is the most reliable field on an
  // invoice object; fall back to invoice.period_end if lines are absent.
  const line = invoice.lines && invoice.lines.data && invoice.lines.data[0];
  return line?.period?.end ?? invoice.period_end ?? null;
}

/**
 * Processes a verified Stripe event. Returns a small result object describing
 * what happened, for logging/observability. Never throws for "expected"
 * conditions (duplicate, unhandled type, missing subscription id) -- those
 * are all normal, non-error outcomes for a webhook consumer.
 */
function handleEvent(event) {
  const handler = HANDLERS[event.type];

  if (!handler) {
    return { status: 'ignored', reason: 'unhandled_event_type', type: event.type };
  }

  const object = event.data && event.data.object;
  if (!object) {
    return { status: 'ignored', reason: 'missing_data_object', type: event.type };
  }

  const mapped = handler(object);
  if (!mapped.subscriptionId) {
    // e.g. an invoice not tied to a subscription (one-off charge)
    return { status: 'ignored', reason: 'no_subscription_on_event', type: event.type };
  }

  // Claim + apply atomically so a mid-flight crash can't desync
  // "event marked processed" from "subscription row updated".
  return runInTransaction(() => {
    const firstTimeSeen = claimEvent(event.id, event.type);
    if (!firstTimeSeen) {
      return { status: 'duplicate_ignored', type: event.type, eventId: event.id };
    }

    const result = applySubscriptionUpdate({
      subscriptionId: mapped.subscriptionId,
      customerId: mapped.customerId,
      status: mapped.status,
      currentPeriodEnd: mapped.currentPeriodEnd,
      eventCreated: event.created,
    });

    return {
      status: result.applied ? 'applied' : 'stale_ignored',
      type: event.type,
      eventId: event.id,
      subscriptionId: mapped.subscriptionId,
      newStatus: mapped.status,
    };
  });
}

module.exports = { handleEvent };
