'use strict';

const express = require('express');
const { getSubscriptionsForCustomer } = require('../db');

const router = express.Router();

// GET /subscriptions/:stripe_customer_id
// Returns every locally-known subscription for that customer (most recently
// updated first). A customer usually has one, but the shape stays correct
// even if they've had more than one over time.
router.get('/:stripe_customer_id', (req, res, next) => {
  const { stripe_customer_id: customerId } = req.params;

  if (!customerId || !customerId.startsWith('cus_')) {
    return res.status(400).json({ error: 'invalid_customer_id' });
  }

  try {
    const rows = getSubscriptionsForCustomer(customerId);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'not_found', stripe_customer_id: customerId });
    }
    return res.status(200).json({ stripe_customer_id: customerId, subscriptions: rows });
  } catch (err) {
    // Delegate to the centralized error handler in server.js.
    next(err);
  }
});

module.exports = router;
