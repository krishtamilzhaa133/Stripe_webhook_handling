'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DATABASE_PATH = process.env.DATABASE_PATH || './data/subscriptions.db';

// Ensure the containing directory exists so a fresh clone "just works".
const dir = path.dirname(DATABASE_PATH);
if (dir && dir !== '.' && !fs.existsSync(dir)) {
  fs.mkdirSync(dir, { recursive: true });
}

// Single, module-level, synchronous connection. better-sqlite3 is
// synchronous by design: no connection pool to leak, no dangling promises,
// no unhandled-rejection surface for DB errors.
const db = new Database(DATABASE_PATH);
db.pragma('journal_mode = WAL');   // better concurrent read/write behavior
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS subscriptions (
    stripe_subscription_id TEXT PRIMARY KEY,
    stripe_customer_id     TEXT NOT NULL,
    status                 TEXT NOT NULL,
    current_period_end     INTEGER,
    last_event_created     INTEGER NOT NULL DEFAULT 0,
    updated_at             TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_subscriptions_customer
    ON subscriptions (stripe_customer_id);

  CREATE TABLE IF NOT EXISTS processed_events (
    event_id     TEXT PRIMARY KEY,
    event_type   TEXT NOT NULL,
    processed_at TEXT NOT NULL
  );
`);

// ---- Prepared statements (compiled once, reused = fast, no leaks) ----

const stmts = {
  markEventProcessed: db.prepare(
    `INSERT OR IGNORE INTO processed_events (event_id, event_type, processed_at)
     VALUES (@event_id, @event_type, @processed_at)`
  ),
  getSubscription: db.prepare(
    `SELECT * FROM subscriptions WHERE stripe_subscription_id = ?`
  ),
  getSubscriptionsByCustomer: db.prepare(
    `SELECT * FROM subscriptions WHERE stripe_customer_id = ? ORDER BY updated_at DESC`
  ),
  insertSubscription: db.prepare(
    `INSERT INTO subscriptions
       (stripe_subscription_id, stripe_customer_id, status, current_period_end, last_event_created, updated_at)
     VALUES (@stripe_subscription_id, @stripe_customer_id, @status, @current_period_end, @last_event_created, @updated_at)`
  ),
  updateSubscription: db.prepare(
    `UPDATE subscriptions
        SET status = @status,
            current_period_end = COALESCE(@current_period_end, current_period_end),
            last_event_created = @last_event_created,
            updated_at = @updated_at
      WHERE stripe_subscription_id = @stripe_subscription_id`
  ),
};

/**
 * Marks a Stripe event ID as processed.
 * Returns true if this call actually inserted it (i.e. this is the first
 * time we've seen the event), false if it was already there (duplicate
 * delivery / replay).
 */
function claimEvent(eventId, eventType) {
  const info = stmts.markEventProcessed.run({
    event_id: eventId,
    event_type: eventType,
    processed_at: new Date().toISOString(),
  });
  return info.changes === 1;
}

/**
 * Applies a status transition to a subscription, guarding against
 * out-of-order webhook delivery: an event is only applied if it is
 * chronologically newer (by Stripe's `event.created`) than the last event
 * that touched this subscription. This is what stops a delayed
 * `invoice.payment_failed` retry from clobbering a subscription that has
 * already recovered via a later `invoice.payment_succeeded`.
 */
function applySubscriptionUpdate({
  subscriptionId,
  customerId,
  status,
  currentPeriodEnd,
  eventCreated,
}) {
  const existing = stmts.getSubscription.get(subscriptionId);
  const now = new Date().toISOString();

  if (!existing) {
    stmts.insertSubscription.run({
      stripe_subscription_id: subscriptionId,
      stripe_customer_id: customerId,
      status,
      current_period_end: currentPeriodEnd,
      last_event_created: eventCreated,
      updated_at: now,
    });
    return { applied: true, reason: 'inserted' };
  }

  if (eventCreated < existing.last_event_created) {
    // A stale/out-of-order event arrived after a newer one already landed.
    return { applied: false, reason: 'stale_event_ignored' };
  }

  stmts.updateSubscription.run({
    stripe_subscription_id: subscriptionId,
    status,
    current_period_end: currentPeriodEnd,
    last_event_created: eventCreated,
    updated_at: now,
  });
  return { applied: true, reason: 'updated' };
}

function getSubscriptionsForCustomer(customerId) {
  return stmts.getSubscriptionsByCustomer.all(customerId);
}

// Wrap the (event-claim + status-update) pair in a single SQLite
// transaction so a crash mid-processing can never leave "event marked
// processed" and "subscription updated" out of sync with each other.
function runInTransaction(fn) {
  return db.transaction(fn)();
}

function close() {
  db.close();
}

module.exports = {
  db,
  claimEvent,
  applySubscriptionUpdate,
  getSubscriptionsForCustomer,
  runInTransaction,
  close,
};
